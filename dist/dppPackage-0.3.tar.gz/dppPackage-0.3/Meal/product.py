class product:

    def __init__(self):
        self.name='cos'
        self.amount=-1
        self.weightInGram=-1