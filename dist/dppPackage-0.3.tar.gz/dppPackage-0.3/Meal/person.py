from enum import Enum

class Person(Enum):
    kobieta = 0.8
    mezczyzna = 1
    dziecko = 0.5